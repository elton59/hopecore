<?php
$conn=mysqli_connect("localhost","hopecore_ken","#Karibu2030","hopecore_hopecore");
?>
