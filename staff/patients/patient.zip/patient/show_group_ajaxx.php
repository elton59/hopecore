<?php
include('connection.php');
 extract($_GET);


if(isset($loan_details))
 {
$l=mysqli_query($conn,"select * from users where email='".$loan_details."'");
$l1=mysqli_fetch_assoc($l);
?>
<div class="row" style="margin-top:10px">
		<div class="col-sm-4">Doctors Firstname</div>
		<div class="col-sm-5">
		<input type="text" value="<?php echo $l1['firstname']; ?>" readonly="true" id="amount" name="firstname" class="form-control" required/></div>
	</div>
  <div class="row" style="margin-top:10px">
  		<div class="col-sm-4">Doctors LastName</div>
  		<div class="col-sm-5">
  		<input type="text" value="<?php echo $l1['lastname']; ?>" readonly="true" id="amount" name="sellingprice" class="form-control" required/></div>
  	</div>
    <div class="row" style="margin-top:10px">
    		<div class="col-sm-4">Doctors Specialization</div>
    		<div class="col-sm-5">
    		<input type="text" value="<?php echo $l1['specialization']; ?>" readonly="true" id="amount" name="sellingprice" class="form-control" required/></div>
    	</div>


<?php
}



?>
