<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; machakos women finance:all rights observed | By : <a href="http://www.phpgurukul.com/" target="_blank">CHARLES N.M</a>
                </div>

            </div>
        </div>
    </footer>